<template>
  <b-container fluid style="background-color:#495057">
    <b-container
      fluid="md">
      <b-navbar
      text-white
      >
        footer
      </b-navbar>
    </b-container>
  </b-container>
</template>

<script>
export default {
    name:'footer',
}
</script>

<style>

</style>