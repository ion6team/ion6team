<template>
  <b-navbar
  class="justify-content-center">
    <b-navbar-brand href='/'>
    <img src='../../assets/logo.jpg'>
    </b-navbar-brand>
  </b-navbar>
</template>

<script>
export default {
    name:'header',
}
</script>

<style>

</style>