<template>
  <b-container <b-container fluid>
    <b-container fluid="md" class="p-4" style="height:600px;">

      <b-row align-v="center" style="height:100%">
        <b-col cols='7'>

          <h2>나도 판매하기</h2>

        </b-col>

        <b-col cols='5'>
          <div style="background-color:orange; width:300px; height:300px"></div>
        </b-col>
      </b-row>



    </b-container>
  </b-container>
</template>

<script>
  export default {
    name: 'sales'
  }
</script>

<style>

</style>