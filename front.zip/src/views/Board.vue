<template>
  <b-container>
    <board-list/>
  </b-container>
</template>

<script>
import BoardList from '../components/BoardList.vue'

export default {
  name:'board',
  components: { BoardList },
  
}
</script>

<style>

</style>